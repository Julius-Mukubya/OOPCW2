package librarySystem;

import java.util.Scanner;

public class Main {
	Scanner read = new Scanner(System.in);
	Library lib = new Library();
	boolean isOnMainMenu = false;
	boolean isOnAddBooksMenu = false;
	boolean isOnViewBooksMenu = false;
	boolean exit = false;


	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		Main obj = new Main();
		obj.mainMenu();
	}
	
	public void exit() {
		exit = true;
		System.out.println("You have quit the program");
		
	}
	
	public void mainMenu() {
		isOnMainMenu = true;
		isOnAddBooksMenu = false;
		isOnViewBooksMenu = false;
		
		int choice;

		
		lib.ReadPhysicalBookFile();
		lib.ReadDigitalBookFile();
		
		while(exit == false) {
			System.out.println();
			System.out.println("____MAIN MENU____");
			System.out.println("1. Add a new Book");
			System.out.println("2. Lend a Book");
			System.out.println("3. Return a Book");
			System.out.println("4. View Books");
			System.out.println("5. Exit");
			
			System.out.println("Please enter choice (1-5): ");
			choice = read.nextInt();
			
			
			switch(choice) {
				case 1:
					OptionAddNewBook();
					break;
				case 2:
					lib.LendPhysicalBooks();
					break;
				case 3:
					lib.ReturnPhysicalBooks();
					break;
				case 4:
					OptionViewBooks();
					break;
				case 5:
					exit();
					break;
				default:
					System.out.println("Invalid input. Please select choice (1-4)");
			}
			
			
		}		
	}
	
	
	public void OptionAddNewBook() {
		isOnMainMenu = true;
		isOnAddBooksMenu = false;
		isOnViewBooksMenu = false;
		
		int choice;
		
		while(exit == false) {
			System.out.println();
			System.out.println("____ADD NEW BOOK MENU___");
			System.out.println("1. Add new Physical Book");
			System.out.println("2. Add new Digital Book ");
			System.out.println("3. Back to Main Menu");
			System.out.println("4. Exit");
			
			System.out.println("Please enter choice (1-4): ");
			choice = read.nextInt();
			
			switch(choice) {
				case 1:
					lib.addNewPhysicalBook();
					OptionToPerformAnotherOperation();
					break;
				case 2:
					lib.addNewDigitalBook();
					OptionToPerformAnotherOperation();
					break;
				case 3:
					mainMenu();
					break;
				case 4:
					exit();
					break;
				default:
					System.out.println("Invalid input. Please select choice (1-4)");
			}
			
		}
		
	}
	
	public void OptionToPerformAnotherOperation() {
		int choice;
		
		if (isOnAddBooksMenu == true) {
			while(exit == false) {
				System.out.println();
				System.out.println("Would you like to:");
				System.out.println("1. Add another Book");
				System.out.println("2. Go Back to Main Menu");
				System.out.println("3. Exit the Program");
				
				System.out.println("Please enter choice (1-3): ");
				choice = read.nextInt();
				
				switch(choice) {
					case 1:
						OptionAddNewBook();
						break;
					case 2:
						mainMenu();
						break;
					case 3:
						exit();
						break;
					default:
						System.out.println("Invalid input. Please select choice (1-3)");
				}
				
			}
			
		} else if(isOnViewBooksMenu == true) {
			while(exit == false) {
				System.out.println();
				System.out.println("Would you like to:");
				System.out.println("1. View more Books");
				System.out.println("2. Go Back to Main Menu");
				System.out.println("3. Exit the Program");
				
				System.out.println("Please enter choice (1-3): ");
				choice = read.nextInt();
				
				switch(choice) {
					case 1:
						OptionViewBooks();
						break;
					case 2:
						mainMenu();
						break;
					case 3:
						exit();
						break;
					default:
						System.out.println("Invalid input. Please select choice (1-3)");
				}
				
			}
			
		}
		
		
	}
	
	public void OptionViewBooks() {
		isOnMainMenu = false;
		isOnAddBooksMenu = false;
		isOnViewBooksMenu = true;
		
		int choice;
		isOnViewBooksMenu = true;
		
		while(exit == false) {
			System.out.println();
			System.out.println("____VIEW BOOKS MENU____");
			System.out.println("1. View all Physical Books");
			System.out.println("2. View all Digital Books ");
			System.out.println("3. View all Books (Both Physical and Digital)");
			System.out.println("4. Back to Main Menu");
			System.out.println("5. Exit");
			
			System.out.println("Please enter choice (1-5): ");
			choice = read.nextInt();
			
			switch(choice) {
				case 1:
					lib.ViewPhysicalBooks();
					OptionToPerformAnotherOperation();
					break;
				case 2:
					lib.ViewDigitalBooks();
					OptionToPerformAnotherOperation();
					break;
				case 3:
					lib.ViewAllBooks();
					OptionToPerformAnotherOperation();
					break;
				case 4:
					mainMenu();
					break;
				case 5:
					exit();
					break;
				default:
					System.out.println("Invalid input. Please select choice (1-4)");
			}
			
		}
		
		
	}
	
	
}
