package librarySystem;

abstract class Book {
	//encapsulated fields
	private String title;
	private String author;
	private String ISBN;
	private boolean isLent;

	// constructor
	Book(String title, String author, String ISBN, boolean isLent){
		this.title = title;
		this.author = author;
		this.ISBN = ISBN;
		this.isLent = isLent;
	}
	
	public String getTitle() {
		return title;
	}
	
	public String getauthor() {
		return author;
	}
	
	public String getISBN() {
		return ISBN;
	}
	
	public boolean getisLent() {
		return isLent;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	public void setauthor(String author) {
		this.author = author;
	}
	
	public void setISBN(String ISBN) {
		this.ISBN = ISBN;
	}
	
	public void setisLent(boolean isLent) {
		this.isLent = isLent;
	}
	
	
}


class DigitalBook extends Book{
	private String format;
	
	DigitalBook(String title, String author, String ISBN, String format){
		super(title, author, ISBN, false);
		this.format = format;
	}
	
	public String getFormat() {
		return format;
	}
	
	public void setisLent() {
		
	}

}

class PhysicalBook extends Book{
	PhysicalBook(String title, String author, String ISBN, boolean isLent){
		super(title, author, ISBN, isLent);
	}
	
	
}




