package librarySystem;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Library {
	String physicalBooksFilepath = "files/physical books.txt";
	String digitalBooksFilepath = "files/digital books.txt";
	String header;
	ArrayList<PhysicalBook> Physicalbooks = new ArrayList<PhysicalBook>();
	ArrayList<DigitalBook> Digitalbooks = new ArrayList<DigitalBook>();
	
	Scanner read = new Scanner(System.in);
	
	
	public void addNewPhysicalBook() {
		System.out.println("Enter Book title of the book being added to the Library: ");
		String title = read.nextLine();
		
		System.out.println("Enter the Author of " + title + ":");
		String author = read.nextLine();
		
		System.out.println("Enter the ISBN of the new book: ");
		String ISBN = read.nextLine();
		
		
		PhysicalBook bookobj = new PhysicalBook(title, author, ISBN, false);
		Physicalbooks.add(bookobj);
		System.out.println();
		System.out.println("Details of Book being added");
		System.out.println("Title: " + title);
		System.out.println("Author: " + author);
		System.out.println("ISBN: " + ISBN);
		System.out.println("You have successfully added " + title + " by " + author + " of ISBN" + ISBN + " to the library");
	}
	
	public void addNewDigitalBook() {
		System.out.println("Enter Book title: ");
		String title = read.nextLine();
		
		System.out.println("Enter the Author of " + title + ":");
		String author = read.nextLine();
		
		System.out.println("Enter the ISBN of new book: ");
		String ISBN = read.nextLine();
		
		System.out.println("Enter the file format of new book: (Example \"PDF\",\"EPUB\",\"AZW/AZW3\",\"MOBI\")");
		String format = read.nextLine();

		
		
		DigitalBook bookobj = new DigitalBook(title, author, ISBN, format);
		Digitalbooks.add(bookobj);
		System.out.println();
		System.out.println("Details of Digital Book being added");
		System.out.println("Title: " + title);
		System.out.println("Author: " + author);
		System.out.println("ISBN: " + ISBN);
		System.out.println("File Format: " + format);
		System.out.println("You have successfully added " + title + " by " + author + " of ISBN" + ISBN + " to the Digital library");
		
	}
	
	public int NumberOfCopiesOfaPhysicalBook(String title, String author) {
		int bookCount = 0;
		for (PhysicalBook book : Physicalbooks) {
			if (book.getTitle().equals(title) && book.getauthor().equals(author)) {
				bookCount++;
			}
			
		}	
		return bookCount;
	}
	
	
	public int DetermineNumberOfPhysicalBooks() {
		return Physicalbooks.size();
	}
	
	public int DetermineNumberOfDigitalBooks() {
		return Digitalbooks.size();
	}

	public void ViewPhysicalBooks() {
		if (DetermineNumberOfPhysicalBooks() == 0) {
			System.out.println();
			System.out.println("You have no Physical Books in your Library");
		}else {
			System.out.println("_____________PHYSICAL BOOKS_____________");
			System.out.println();
			for (PhysicalBook book : Physicalbooks) {
				System.out.println("Title: " + book.getTitle());
				System.out.println("Author: " + book.getauthor());
				System.out.println("ISBN: " + book.getISBN());
				System.out.println("IsLent: " + book.getisLent());
				System.out.println();
			}
			System.out.println("_____________END OF PHYSICAL BOOKS_____________");		
		}
		
	}
	
	public void ViewDigitalBooks() {
		
		if (DetermineNumberOfDigitalBooks() == 0) {
			System.out.println();
			System.out.println("You have no digital books in your library");
		}else {
			System.out.println("_____________DIGITAL BOOKS_____________");
			System.out.println();
			for (DigitalBook book : Digitalbooks) {
				System.out.println("Title: " + book.getTitle());
				System.out.println("Author: " + book.getauthor());
				System.out.println("ISBN: " + book.getISBN());
				System.out.println("Format: " + book.getFormat());
				System.out.println();
			}
			System.out.println("_____________END OF DIGITAL BOOKS_____________");
				
		}
		
		
	}
	
	public void ViewAllBooks() {
		ViewPhysicalBooks();
		ViewDigitalBooks();	
	}
	
	public void ReturnPhysicalBooks() {
		
		System.out.println("Enter title of Book being returned: ");
		String title = read.nextLine();
		
		System.out.println("Enter author of Book being returned: ");
		String author = read.nextLine();
		
		System.out.println("Enter ISBN of Book being returned: ");
		String ISBN = read.nextLine();
		
		
		for (PhysicalBook book : Physicalbooks) {
			
			if (book.getTitle().equals(title) && book.getauthor().equals(author) && book.getISBN().equals(ISBN)) {
				if (book.getisLent() == true) {
					book.setisLent(false);		
					int bookCount = NumberOfCopiesOfaPhysicalBook(title, author) + 1;
					System.out.println("You have successfully returned the book " + book.getTitle() + " by" + book.getauthor());
					
				}else {
					System.out.println("Invalid Request. You are returning a book that wasn't lent");
				}
					
			}else {
				System.out.println("Invalid Request. You can't return a book that wasn't part of the library");
			}
			
		}
	}
	
	public void LendPhysicalBooks() {
		
		System.out.println("Enter title of Book to be lent: ");
		String title = read.nextLine();
		
		System.out.println("Enter author of Book to be lent: ");
		String author = read.nextLine();
		
		System.out.println("Enter ISBN of Book to be lent: ");
		String ISBN = read.nextLine();
		
		
		boolean isFound = false;
		for (PhysicalBook book : Physicalbooks) {
			
			if (book.getTitle().equals(title) && book.getauthor().equals(author) && book.getISBN().equals(ISBN)) {
				isFound = true;
				if (book.getisLent() == false) {
					book.setisLent(true);
					int bookCount = NumberOfCopiesOfaPhysicalBook(title, author) - 1;
					System.out.println("You have successfully lent the book " + book.getTitle() + " by " + book.getauthor());
				}else {
					System.out.println("Invalid Request. You can't lend a book that is already lent");
				}	
			}
		}
		
		if (isFound == false) {
			System.out.println("Invalid Request. You can't lend a book that doesn't exist in the library");
		}
		
		
	}
	
	public void ReadPhysicalBookFile() {
		
		try {
			File physicalBookFile = new File(physicalBooksFilepath);
			Scanner read = new Scanner(physicalBookFile);
			
			
			header = read.nextLine();	//Skip the header row
			
			// Reading Physical books
			while (read.hasNextLine()) {
				
				// Reading a single line and assiging individual attributes to the array
				String[] attributes = read.nextLine().split(",");
				
				// Assigning attributes to variables
				String title = attributes[0];
				String author = attributes[1];
				String ISBN = attributes[2];
				boolean isLent = Boolean.parseBoolean(attributes[3]);
				
				
				
				// Creating book object
				PhysicalBook PhysicalbookObject = new PhysicalBook(title, author, ISBN, isLent);
				
				Physicalbooks.add(PhysicalbookObject);
				
			}
			
		} catch(FileNotFoundException e) {
			System.out.println("File not Found");
		}
		
		
	}
		
	public void ReadDigitalBookFile() {
		
		try {
			File digitalBookFile = new File(digitalBooksFilepath);
			Scanner read = new Scanner(digitalBookFile);
			
			
			header = read.nextLine();	//Skip the header row
			
			// Reading Physical books
			while (read.hasNextLine()) {
				
				// Reading a single line and assiging individual attributes to the array
				String[] attributes = read.nextLine().split(",");
				
				// Assigning attributes to variables
				String title = attributes[0];
				String author = attributes[1];
				String ISBN = attributes[2];
				String format = attributes[3];
				
				
				
				// Creating book object
				DigitalBook digitalBookObject =  new DigitalBook(title, author, ISBN, format);
				
				Digitalbooks.add(digitalBookObject);
				
			}
			
		} catch(FileNotFoundException e) {
			System.out.println("File not Found");
		}
		
		
	}
	
	public void WriteToPhysicalBookFile() {
		
		try {
			File file = new File(physicalBooksFilepath);
			
			// Overwriting
			FileWriter overwriter = new FileWriter(physicalBooksFilepath);
			overwriter.close();
			
			
			//Appending
			FileWriter writer = new FileWriter(physicalBooksFilepath, true);

			
			
			String title;
			String author;
			String ISBN;
			String isLent;
			
			writer.write(header);
			for (PhysicalBook book : Physicalbooks) {
				title = book.getTitle();
				author = book.getauthor();
				ISBN = book.getISBN();
				isLent = Boolean.toString(book.getisLent()); 
				String line = title + "," + author + "," + ISBN + "," + isLent + "\n";
				writer.write(line);
			}
			writer.close();
			
		}catch(IOException e) {
			System.out.println("Error occured while writing to file");
		}
		
	}
		
	public void WriteToDigitalBookFile() {
		
		try {
			File file = new File(digitalBooksFilepath);
			
			// Overwriting
			FileWriter overwriter = new FileWriter(digitalBooksFilepath);
			overwriter.close();
			
			
			//Appending
			FileWriter writer = new FileWriter(digitalBooksFilepath, true);

			
			
			String title;
			String author;
			String ISBN;
			String format;
			
			writer.write(header);
			for (DigitalBook book : Digitalbooks) {
				title = book.getTitle();
				author = book.getauthor();
				ISBN = book.getISBN();
				format = book.getFormat(); 
				String line = title + "," + author + "," + ISBN + "," + format + "\n";
				writer.write(line);
			}
			writer.close();
			
		}catch(IOException e) {
			System.out.println("Error occured while writing to file");
		}
		
	}
	
}
